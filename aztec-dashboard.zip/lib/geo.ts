export const REGION_CENTROIDS = {
  'Africa': { lat: 7.1881, lng: 21.0938 },
  'Asia': { lat: 34.0479, lng: 100.6197 },
  'Europe': { lat: 54.5260, lng: 15.2551 },
  'North America': { lat: 54.5260, lng: -105.2551 },
  'South America': { lat: -8.7832, lng: -55.4915 },
  'Oceania': { lat: -22.7359, lng: 140.0188 },
}
