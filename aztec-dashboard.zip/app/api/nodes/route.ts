import { NextResponse } from 'next/server'
import { REGION_CENTROIDS } from '@/lib/geo'

/**
 * Node source options:
 * 1) (Recommended) Opt‑in beacon – people running nodes hit this endpoint (POST) with their city/country).
 * 2) (Fallback/demo) Pull region distribution from Nethermind's Aztec P2P Explorer (best‑effort scrape).
 * 3) (Manual) Supply a JSON URL via NODE_LIST_JSON_URL env var with an array of { lat, lng, city, country }.
 */

export const dynamic = 'force-dynamic'

export async function GET() {
  try {
    // Option 3: external JSON override
    const url = process.env.NODE_LIST_JSON_URL
    if (url) {
      const res = await fetch(url, { next: { revalidate: 60 } })
      if (res.ok) {
        const list = await res.json()
        return NextResponse.json({ nodes: Array.isArray(list) ? list : [] })
      }
    }

    // Option 2: Best‑effort scrape for regional distribution from Nethermind P2P Explorer
    // NOTE: This returns synthetic points around region centroids; it is privacy‑preserving and approximate.
    const htmlRes = await fetch('https://aztec.nethermind.io/', { cache: 'no-store' })
    let nodesByRegion: Record<string, number> | null = null
    if (htmlRes.ok) {
      const html = await htmlRes.text()
      // Very light heuristic: look for region names and counts nearby.
      const regionRegex = /(Africa|Asia|Europe|North America|South America|Oceania)[^\d]*(\d{1,6})/gi
      let m: RegExpExecArray | null
      nodesByRegion = {}
      while ((m = regionRegex.exec(html)) !== null) {
        nodesByRegion[m[1]] = (nodesByRegion[m[1]] || 0) + Number(m[2])
      }
      if (Object.keys(nodesByRegion).length === 0) nodesByRegion = null
    }

    // Build synthetic geocoded nodes from region counts (random jitter around centroid to render on map)
    if (nodesByRegion) {
      const nodes: Array<any> = []
      for (const [region, count] of Object.entries(nodesByRegion)) {
        const centroid = REGION_CENTROIDS[region as keyof typeof REGION_CENTROIDS]
        if (!centroid) continue
        for (let i = 0; i < Math.min(count, 500); i++) {
          // jitter within ~2° box for visual dispersion
          const lat = centroid.lat + (Math.random() - 0.5) * 2
          const lng = centroid.lng + (Math.random() - 0.5) * 2
          nodes.push({ lat, lng, region })
        }
      }
      return NextResponse.json({ nodes, approximate: true })
    }

    // Final fallback: small demo dataset so the map renders out‑of‑the‑box
    return NextResponse.json({
      nodes: [
        { lat: 51.509, lng: -0.118, city: 'London', country: 'UK' },
        { lat: 40.7128, lng: -74.006, city: 'New York', country: 'USA' },
        { lat: 6.5244, lng: 3.3792, city: 'Lagos', country: 'Nigeria' },
        { lat: 48.8566, lng: 2.3522, city: 'Paris', country: 'France' },
        { lat: -33.8688, lng: 151.2093, city: 'Sydney', country: 'Australia' },
      ],
      demo: true,
    })
  } catch (e) {
    return NextResponse.json({ nodes: [], error: 'failed_to_fetch' }, { status: 200 })
  }
}

// Simple opt‑in collector (optional): POST { lat, lng, city?, country? } with BEACON_TOKEN
export async function POST(req: Request) {
  try {
    const secret = process.env.BEACON_TOKEN
    const hdr = req.headers.get('x-beacon-token')
    if (!secret || hdr !== secret) return NextResponse.json({ ok: false }, { status: 401 })
    const body = await req.json()
    // In a production app, persist to KV/DB. Here we just echo for demo.
    return NextResponse.json({ ok: true, received: body })
  } catch (e) {
    return NextResponse.json({ ok: false }, { status: 400 })
  }
}
